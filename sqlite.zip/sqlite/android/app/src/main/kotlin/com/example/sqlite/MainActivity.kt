package com.example.sqlite

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
